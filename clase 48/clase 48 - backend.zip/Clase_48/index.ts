// import { bgBlue, red, bold, parse, format} from "./devDependencias.ts"

// console.log(parse("12-07-2022", "dd-MM-yyyy"));
// console.log(bgBlue(red(bold('Hola Deno!!'))));
// console.log(format(new Date(2019, 0, 20), "dd-MM-yyyy"));

import {Application} from "./devDependencias.ts"
import { router } from "./routes/index.ts";

const app = new Application();

app.use(router.routes())



// se debe inicializar la aplicacion
app.use((ctx)=>{
    ctx.response.body = "Hello Deno!!"
})

app.listen({port:8080})
console.log("Server run on port 8080");

