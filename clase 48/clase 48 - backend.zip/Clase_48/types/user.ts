
export interface User {
    uuid:String;
    name:String;
    birthday:Date;
}